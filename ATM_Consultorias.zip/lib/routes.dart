// ignore_for_file: non_constant_identifier_names

class Routes {
  static String HOME = '/';
  static String COMPANY = '/company';
  static String SERVICE = '/service';
  static String CLIENTS = '/clients';
  static String CONTACT = '/contact';
}